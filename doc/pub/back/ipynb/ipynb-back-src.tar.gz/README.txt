This IPython notebook back.ipynb does not require any additional
programs.
