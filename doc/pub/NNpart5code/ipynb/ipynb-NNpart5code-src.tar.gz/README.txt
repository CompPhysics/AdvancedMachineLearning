This IPython notebook NNpart5code.ipynb does not require any additional
programs.
