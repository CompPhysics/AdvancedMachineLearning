This IPython notebook week9.ipynb does not require any additional
programs.
