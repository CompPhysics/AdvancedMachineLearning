This IPython notebook week2.ipynb does not require any additional
programs.
