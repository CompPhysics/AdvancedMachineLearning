This IPython notebook PINNs.ipynb does not require any additional
programs.
