This IPython notebook Generative.ipynb does not require any additional
programs.
