This IPython notebook RNN.ipynb does not require any additional
programs.
