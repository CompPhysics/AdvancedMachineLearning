This IPython notebook CNNandmore.ipynb does not require any additional
programs.
