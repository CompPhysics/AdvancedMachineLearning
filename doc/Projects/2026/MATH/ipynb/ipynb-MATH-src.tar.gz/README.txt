This IPython notebook MATH.ipynb does not require any additional
programs.
